using CadEditor;
using System.Collections.Generic;
//css_include Settings_CapcomBase.cs;
//css_include Settings_Megaman3Base.cs
public class Data:Megaman3Base
{
  protected override int LEVEL_NO() { return 10; }
}