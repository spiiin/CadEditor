------------------------------------------------------------------------------
[ENG]
Chip and Dale Level Editor
Version 1.0
-------------------------------------------------------------------------------
Control: 

Editor screen.
Left panel � select an active object
Screen no � choose screen for editing. Some screens (185-256) are used to store data about the objects, so they can not be edited
View type � select view from tile or path-map
 Game � change the editor type (general or game-specific)
       
(In the general editor, the type switch shows only SCREEN VIEW IN THE EDITOR, and not their view in the game. The level parameters determine how they will look in the game).
    Video Block � select an active videomemory bank
    Big Block � select an active Macro Block set
    Block � select an active block set 
    Pallete � select an active pallete
    Width � level layout width
    Height � level layout height
   
�View as� and �Door� � select which videomemory block will be used to view the screen (any videomemory block can be used, but it is better to choose one that will be really used in the game).
   Edit tiles � open macrotiles editor
    Edit objs � open tiles editor
    Edit layout � open level form editor
    Edit enemies � open enemies editor
    Save � save results to a file (all edited screens are saved simultaneously)


Macrotiles editor
Select tileset � select tileset for editing (sets can be shared between several levels/doors).
View with level / door � view videomemory block for watch tileset. For correct editing you must select the right videomemory block.

 Tiles editor
 Level � select level (* objects can be shared between several levels/doors, same as macrotiles)
 Door � select videomemory to watch tiles
 View with subpallete � view pallete part to watch videomemory

Edit backs � open background editor behind the collected objects. There are 16 backgrounds per a level, and the one selected by the game depends on the last 4 bytes of the object number. Thus, if a box number is FC � 1111 1100, the 4 low bytes mean Index 12 in the backs array, hence after the box is raised the tile under it will be replaced with Object 12.
  
 Form editor
Left panel � select an active element (screen, scroll or door).
Central panel � click on the blue arrow invert direction of sorting for objects on select stage (if using left or bidirect scroll, you must choose the right stage direction or the enemies order will be wrong!!!).
Right panel � View screen order in the game.
Make preview � The most important button :) It allows you to check correctness of the constructed level. Clicking on it will calk the screen order and its videomemory as well as pallete taking into account all switch doors. You can view small screens preview to check that screens use correct videomemory blocks.
Edit level params � open level/doors params editor
   
 Level/doors params editor
 Select level � select the level or door for params editing
 Objects/ Back Graphic Bank No � select the used videomemory block number
Palette No, Palette 2 No - select primary and secondary pallete for the level (secondary is used for painting some objects as Zipper or Monterey Jack and for blink)
Palette blink byte - I actually don�t know how it works
  Start screen index � The first screen number in layout (screens are numbered from left to right, top to bottom)
     For example, 1st level layout:
       layout @ 1E2D3: (level 1)
        1E2D3:
        16 17 18 19 1A 1B 00 <- inside area 00
        0F 10 11 12 13 14 15
        0E 00 00 00 1D 00 1C <- boss entrance 12
        08 09 0A 0B 0C 0D 00
        00 00 00 00 00 07 00
        01 02 03 04 05 06 00
Source: http://acmlm.no-ip.org/board/thread.php?id=5821
     
Start room - 01, it has index 23 in layout. The start rooms for levels must be in the left-bottom corner of the layout, and any position is possible for the doors.
     
Layout width, Layout height � Level size. You can not increase the total area or height for now!!! (the area because neighboring data will be mixed, and the height � because along with the layout, there are also special direction bytes for each stage of the level, and in the original ROM, they are located next to the object description).
Layout address, Scroll doors address, Stage direction address - read only addresses at this point.
Big block id � number of "architecture" - a set of large and small tiles of which the screens level will be built.
Music no � track number on the level.
Start screen X, Start screen Y � you have to specify the correct coordinates of the starting positions for the doors, otherwise the enemy after entering the door to stop appearing! The coordinates are measured from left to right and top to bottom (for example, the coordinates of the first level rasladki the very first room to be X = 0, Y = 5).
Player X, Player Y � starting position chipmunk on a new screen when you enter to the door.
   
Enemies editor
Select level � select a level for editing
Screen No � select the game screen. Arrows enable you to scroll the level in any direction. The screens are drawn from the already calculated correct videomemory (calculation based on a set of doors on the level and scrolls). If errors occur during the rendering, it is necessary to configure the level of form and properties of the doors in the editor form. Enemies are sorted by editor in the right order that they appear correctly in the game (depending on the form level, doors, and directions - all set in the editor form level). (!) Because of the hack developers, at level D objects can not be properly sorted. In the current version of the editor you CAN NOT edit the enemies on this level. This is possible only in version 0.4.

Right panel - view enemies (the coordinates, screen no and type of enemy). Press Delete button on the keyboard for remove the selected enemy. Clear all objects at screen � delete all enemies at the selected screen.

Manual sort � switch off automated enemies sorting. After this is done, arrow buttons are used to set the order. This option is used when in the layout editor such a level form is created which makes automatic sorting of enemies impossible. Enemies should be put in the order in which they appear in the game, and an additional condition is to be observed � after entering the door, the game uses the first enemy found on the top of the list with suitable coordinates (to avoid errors, the easiest way is to make doors only to the new stages).
 
   
(!!!) It is recommended to copy the file from the intermediate result to a separate folder and check the performance more often!

Feedback: sanya.boyko@gmail.com
