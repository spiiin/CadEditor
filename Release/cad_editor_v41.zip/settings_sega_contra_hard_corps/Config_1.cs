using CadEditor;
using System.Collections.Generic;
using System.Drawing;

public class Config
{
  public string getFileName()      { return "d:/DEV/MYGIT/CadEditor/Contra - Hard Corps (U) [!].gen";                     }
  public string getDumpName()      { return "d:/DEV/MYGIT/CadEditor/settings_sega_contra_hard_corps/map_11.bin";     }
  public string getConfigName()    { return "d:/DEV/MYGIT/CadEditor/settings_sega_contra_hard_corps/Settings_SegaContra_1.cs"; }
  public bool showDumpFileField()  { return true;  }
}