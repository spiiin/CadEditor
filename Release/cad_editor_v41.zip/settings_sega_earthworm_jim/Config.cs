using CadEditor;
using System.Collections.Generic;
using System.Drawing;

public class Config
{
  public string getFileName()      {  return "Earthworm Jim (U) [!].bin";                     }
  public string getDumpName()      { return "settings_sega_earthworm_jim/SegaEWJ_1.bin";     }
  public string getConfigName()    { return "settings_sega_earthworm_jim/Settings_EWJ-1.cs"; }
  public bool showDumpFileField()  { return true;  }
}