using CadEditor;
using System.Collections.Generic;
using System.Drawing;

public class Config
{
  public string getFileName()      { return "settings_sega_mickey_mania/metatiles1.bin";     }
  public string getDumpName()      { return "settings_sega_mickey_mania/map1.bin";           }
  public string getConfigName()    { return "settings_sega_mickey_mania/Settings_MickeyMania-1.cs";}
  public bool showDumpFileField()  { return true;  }
}