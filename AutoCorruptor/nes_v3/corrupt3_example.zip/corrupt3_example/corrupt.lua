--------------------------------------------------------
START_ADDR = 0x10
END_ADDR   = rom.readbyte(4) * 0x4000 + 0x10
CUR_ADDR = START_ADDR
WRITE_VALUE = 0x33
STEP = 1
--ROM_NAME = ""
CDL_FILE = ""

--------------------------------------------------------
savestate.load(savestate.create(3))
FRAME_FOR_SCREEN = emu.framecount()
--------------------------------------------------------
cdlFile = 0;
cdlData = ""
if CDL_FILE ~= "" then
    cdlFile = assert(io.open(CDL_FILE, "rb"))
    cdlData = cdlFile:read("*all")
end;
--------------------------------------------------------
shas = {}
CYCLES = 0

--emu.loadrom(ROM_NAME);
emu.speedmode("maximum");

lastValue = rom.readbyte(START_ADDR)
savestate.load(savestate.create(2))

needReturn = true
    
while (true) do
  if (emu.framecount() > FRAME_FOR_SCREEN) then
    if needReturn then
        local ppuNametable = ppu.readbyterange(0x2000, 0x400)
        local hash  = gethash(ppuNametable, string.len(ppuNametable));
        if (not shas[hash]) then
          print("Found new screen at addr "..tostring(CUR_ADDR).." hash "..tostring(hash));
          local fname = string.format("%05X", CUR_ADDR)..".png";
          gui.savescreenshotas(fname);
          emu.frameadvance();
          shas[hash] = true;
        end;
        rom.writebyte(CUR_ADDR, lastValue);
        needReturn = false;
    end;
    CUR_ADDR = CUR_ADDR + STEP;
    CYCLES = CYCLES + 1;
   
    if (CYCLES % 100) == 0 then
        print(string.format("%05X", CUR_ADDR));
    end;
    
    if (CUR_ADDR > END_ADDR) then
      gui.text(20,20, string.format("WORK COMPLETE!"));
      emu.pause();
    end;
    
    local cdlCharMask = 0xFF;
    if CDL_FILE ~= "" then
        local cdlChar = string.byte(cdlData:sub(CUR_ADDR+0x10,CUR_ADDR+0x10))
        cdlCharMask = bit.band(cdlChar, 0x22);
    end;
    
    if CDL_FILE == "" or cdlCharMask ~= 0 then
        lastValue = rom.readbyte(CUR_ADDR);
        rom.writebyte(CUR_ADDR, WRITE_VALUE);
        needReturn = true;
        savestate.load(savestate.create(2))
    end;
  end;
  emu.frameadvance();
end;