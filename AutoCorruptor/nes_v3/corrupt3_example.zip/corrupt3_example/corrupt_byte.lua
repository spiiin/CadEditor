CUR_ADDR = 0x1A900
FRAME_FOR_SCREEN =  450
CUR_WRITE_VALUE = 0x0
  
rom.writebyte(CUR_ADDR, CUR_WRITE_VALUE);
s = savestate.create(2)
savestate.load(s)

while (true) do
  if (emu.framecount() > FRAME_FOR_SCREEN) then
    local fname = string.format("%03d", CUR_WRITE_VALUE)..".png";
    gui.savescreenshotas(fname);
    CUR_WRITE_VALUE = CUR_WRITE_VALUE + 1;
    rom.writebyte(CUR_ADDR, CUR_WRITE_VALUE);
    s = savestate.create(2)
    savestate.load(s)
    if (CUR_WRITE_VALUE == 256) then
      emu.pause();
    end;
  end;
  emu.frameadvance();
end;