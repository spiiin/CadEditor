# -*- coding: utf-8 -*-
BLOCK_WIDTH  = 16
BLOCK_HEIGHT = 16
from PIL import Image
def cutBlock(pp):
  im = Image.open(pp)
  X = 8 #загрузить скриншот в любой графический редактор, чтобы посмотреть координаты начала блока
  Y = 128
  imCut = im.crop((X,Y,X+BLOCK_WIDTH,Y+BLOCK_HEIGHT)) 
  imCut.save("_" + pp)

BLOCK_COUNT = 128

for x in xrange(BLOCK_COUNT):
  cutBlock(r"%03d.png"%x)  

imBig = Image.new("RGB", (BLOCK_WIDTH*BLOCK_COUNT,BLOCK_HEIGHT))
for x in xrange(BLOCK_COUNT):
  im = Image.open("_%03d.png"%x)
  imBig.paste(im, (BLOCK_WIDTH*x,0,BLOCK_WIDTH*x+BLOCK_WIDTH,BLOCK_HEIGHT))

#imBig.save("outStrip.png")
imBig64 = imBig.resize((BLOCK_COUNT*64,64))
imBig64.save("outStrip.png")