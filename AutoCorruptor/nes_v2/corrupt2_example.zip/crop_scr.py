# -*- coding: utf-8 -*-
import Image
def cutBlock(pp):
  im = Image.open(pp)
  X = 96 #загрузить скриншот в любой графический редактор, чтобы посмотреть координаты начала блока
  Y = 96
  imCut = im.crop((X,Y,X+32,Y+32)) 
  imCut.save("_" + pp)
  
for x in xrange(256):
  cutBlock(r"%03d.png"%x)
  
BLOCK_COUNT = 102
MAX_BLOCK_COUNT = 256
imBig = Image.new("RGB", (32*MAX_BLOCK_COUNT,32))
for x in xrange(BLOCK_COUNT):
  im = Image.open("_%03d.png"%x)
  imBig.paste(im, (32*x,0,32*x+32,32))

imBig64 = imBig.resize((MAX_BLOCK_COUNT*64,64))
imBig64.save("outStrip.png")