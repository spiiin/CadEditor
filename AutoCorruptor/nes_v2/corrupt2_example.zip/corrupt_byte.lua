require "gd"
CUR_ADDR = 0x105E8
FRAME_FOR_SCREEN =  7035
CUR_WRITE_VALUE = 0x0
  
rom.writebyte(CUR_ADDR, CUR_WRITE_VALUE);
s = savestate.create(2)
savestate.load(s)

while (true) do
  if (emu.framecount() > FRAME_FOR_SCREEN) then
    local gdStr = gui.gdscreenshot();
    local gdImg = gd.createFromGdStr(gdStr);
    local fname = string.format("%03d", CUR_WRITE_VALUE)..".png";
    gdImg:png(fname)
    CUR_WRITE_VALUE = CUR_WRITE_VALUE + 1;
    rom.writebyte(CUR_ADDR, CUR_WRITE_VALUE);
    s = savestate.create(2)
    savestate.load(s)
    if (CUR_WRITE_VALUE == 256) then
      emu.pause();
    end;
  end;
  emu.frameadvance();
end;