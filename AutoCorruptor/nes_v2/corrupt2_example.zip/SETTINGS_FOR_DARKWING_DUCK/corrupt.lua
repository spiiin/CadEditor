require "gd"

START_ADDR = 0x10
END_ADDR   = 0x20010
CUR_ADDR = START_ADDR
FRAME_FOR_SCREEN =  2200
WRITE_VALUE = 0x33
STEP = 32

shas = {}

lastValue = rom.readbyte(START_ADDR)
s = savestate.create(2)
savestate.load(s)
    
while (true) do
  if (emu.framecount() > FRAME_FOR_SCREEN) then
    local gdStr = gui.gdscreenshot();
    local hash  = emu.calchash(gdStr, string.len(gdStr));
    if (not shas[hash]) then
      print("Found new screen "..tostring(hash));
      local fname = string.format("%05X", CUR_ADDR)..".png";
      local gdImg = gd.createFromGdStr(gdStr);
      gdImg:png(fname)
      shas[hash] = true;
    end;
    rom.writebyte(CUR_ADDR, lastValue);
    CUR_ADDR = CUR_ADDR + STEP;
    lastValue = rom.readbyte(CUR_ADDR);
    rom.writebyte(CUR_ADDR, WRITE_VALUE);
    s = savestate.create(2)
    savestate.load(s)
    gui.text(20,20, string.format("%05X", CUR_ADDR));
    if (CUR_ADDR > END_ADDR) then
      emu.pause();
    end
  end;
  emu.frameadvance();
end;